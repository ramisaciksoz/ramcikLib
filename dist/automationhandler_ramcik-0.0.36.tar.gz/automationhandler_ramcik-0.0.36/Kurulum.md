## 🚀 Hızlı Yayınlama Komutu (ve PC'de Kütüphaneyi Güncelleme)

Aşağıdaki PowerShell scripti, seni `pyproject.toml` dosyasındaki versiyonu güncellemen konusunda uyarır. `y` dersen işlem devam eder, `n` dersen iptal edilir.

PowerShell terminaline **blok olarak yapıştırarak** çalıştırabilirsin:

```powershell
$cevap = Read-Host "`n`npyproject.toml dosyasındaki versiyonu güncelledin mi? (y/n)"

if ($cevap -ne "y") {
    Write-Host "❗ Lütfen önce pyproject.toml dosyasındaki versiyonu güncelle. Güncelledikten sonra bu scripti tekrar çalıştır." -ForegroundColor Red
    return
}

Write-Host "`n✅ Devam ediliyor...`n" -ForegroundColor Green

# Eski build dosyalarını sil
Remove-Item -Recurse -Force dist\*

# Yeni build oluştur
py -m build

# TestPyPI'ye yükle (önceden .pypirc varsa token istemez)
py -m twine upload --repository testpypi --config-file "$env:USERPROFILE\OmnesCore\.pypirc" dist\*

# Yerel kurulumu güncelle
pip uninstall AutomationHandler-ramcik -y
pip install -i https://test.pypi.org/simple/ AutomationHandler-ramcik
```

---
# Kütüphane Yayınlama ve Senkronizasyon Adımları

---

**Eğer kodu değiştirdiysen:**

## 0. Versiyon güncellemesi

`pyproject.toml` dosyasındaki version değerini güncelle:

```toml
version = "0.0.6"  →  version = "0.0.7"
```

---

## 1. Eski build dosyalarını sil

`dist` klasöründeki tüm eski dosyaları sil:

```bash
rm -rf dist/*
```

---

## 2. Yeni build oluştur

Kütüphane klasöründeyken terminalde şunu çalıştır:

```bash
py -m build
```

---

## 3. TestPyPI’ye yükleme

Aşağıdaki komutu terminalde çalıştır:

```bash
py -m twine upload --repository testpypi --config-file "$env:USERPROFILE\OmnesCore\.pypirc" dist/*
```

Eğer `.pypirc` dosyasının içinde geçerli bir token varsa, tekrar girmen gerekmez.  
Aksi halde, terminalde token girmen istenir.

Token’a ihtiyaç duyarsan, `token.txt` dosyasındaki değeri yapıştır:

```
pypi-AgENdGVzdC5weXBpLm9yZwIkNDI5NzllZGYtNGNlOS00MmY1LWI4MTYtMGQ4MmE5ZGYxMTIxAAIqWzMsImYyODY3NjcxLTQxMTItNDJmYi05N2VjLTQzNTEwMGY4NmVmZCJdAAAGIIklG3zsfQA4I9zOAJcegzSicUCHtK5W3aQYUC_GhULL
```

---

## 4. Versiyon kontrolü

Yüklemenin başarılı olup olmadığını TestPyPI'de kontrol et:

[TestPyPI – AutomationHandler-ramcik](https://test.pypi.org/project/AutomationHandler-ramcik/)

---

## 5. Yerel kurulumu güncelle

Eski versiyonu kaldır ve güncelini yükle:

```bash
# Yerel kurulumu güncelle
pip uninstall AutomationHandler-ramcik -y
pip install -i https://test.pypi.org/simple/ AutomationHandler-ramcik
```

## 6. GitHub’a yükle

```bash
git add .
git commit -m "Versiyon 0.0.7 güncellendi"
git push
```

---

## 7. GitHub üzerinde kontrol et

[GitHub – ramcikLib](https://github.com/ramisaciksoz/ramcikLib)

---

## Kaynak

[Python Packaging Tutorial](https://packaging.python.org/en/latest/tutorials/packaging-projects/)

---

## Ek Uyarılar

---

**Eğer kütüphane içinde yeni bir kütüphane kullandıysan:**

- `init_tools.py` dosyasındaki `oc_install_deps` fonksiyonunu düzenlemeyi unutma.
- `README.md` dosyasındaki "Requirements" başlığı altındaki `Dependencies:` kısmını güncelle.
- Yeni eklediğin kütüphaneyi diğer kullandığın bilgisayarlarda da yüklemeyi unutma.

---

**Eğer yeni bir ortam değişkeni tanımladıysan:**

- `init_tools.py` içindeki `oc_create_myenvfile` fonksiyonunda `required_env_vars` listesine hem Windows hem Linux için ekle.
- Kullanıcı klasörü içindeki `myenvfile` dosyasını güncelle.
- `README.md` içindeki "Define Environment Variables" başlığını güncelle.
- Yeni ortam değişkenini diğer kullandığın bilgisayarlara da eklemeyi unutma.

---
